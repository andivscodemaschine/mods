def hi(lol: str) -> str:
    print(lol)
