from testprojekt import hi
import numpy as np

hi("hallo" + np.random.choice(["Moin", "Hallo", "Hi"]))
