from .testprojekt import *
from .importtt import *

__all__ = ['hi']


__version__ = "0.1.0"
__author__ = "Andivscodemachine"
__doc__ = "Andimointestprojekt is a test project for Python package structure and imports."
